import argparse
import copy
import math
import random
import time

import numpy as np
import pandas as pd
import torch
import torch.nn.functional as F
from sklearn.metrics import roc_auc_score, average_precision_score, f1_score, accuracy_score, recall_score, \
    precision_score, roc_curve, precision_recall_curve

from GATCL import GATCNNMF
from just import get_just_result
from utils import build_heterograph, sort_matrix, GKL
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

# 参数设置
parser = argparse.ArgumentParser()
parser.add_argument('--no-cuda', action='store_true', default=True,
                    help='Disables CUDA training.')
parser.add_argument('--seed', type=int, default=2022, help='Random seed.')
parser.add_argument('--epochs', type=int, default=1,  # 基本上100就已经达到效果了
                    help='Number of epochs to train.')
parser.add_argument('--lr', type=float, default=0.0001,
                    help='Learning rate.')
parser.add_argument('--weight_decay', type=float, default=1e-7,
                    help='Weight decay (L2 loss on parameters).')
parser.add_argument('--hidden', type=int, default=64,
                    help='Dimension of representations')




if __name__ == '__main__':
    device = torch.device("cpu")
    args = parser.parse_args()
    # np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    # 读取邻接矩阵,625*93,associations:674
    A = np.loadtxt('./data/associationMatrix_625_93.csv', delimiter=',')
    circSimi = np.loadtxt('./data/Integrated_sqe_fun_circRNA_similarity_625.csv', delimiter=',')
    disSimi = np.loadtxt('./data/Integrated_gip_DO_disease_similarity_93.csv', delimiter=',')

    # circ_dis_numpy->tensor
    circSimi_mat = torch.from_numpy(circSimi).to(torch.float32)
    disSimi_mat = torch.from_numpy(disSimi).to(torch.float32)

    circrna_disease_matrix = np.copy(A)
    rna_numbers = circrna_disease_matrix.shape[0]
    dis_number = circrna_disease_matrix.shape[1]

    # 寻找正样本的索引
    positive_index_tuple = np.where(circrna_disease_matrix == 1)
    positive_index_list = list(zip(positive_index_tuple[0], positive_index_tuple[1]))
    # 随机打乱
    random.shuffle(positive_index_list)
    # 将正样本分为5个数量相等的部分
    positive_split = math.ceil(len(positive_index_list) / 5)

    all_aupr = []
    all_auc = []
    all_F1 = []
    all_acc = []
    all_recall = []
    all_precision = []
    y_label_ =[]
    y_pred_ =[]
    outputs_ = []

    count = 0
    mean_fpr = np.linspace(0, 1, 100)
    all_tpr = []
    # 5-fold
    t1 = time.time()
    # 创建ROC和PR图形

    plt.figure(figsize=(8, 6))
    roc_figure = plt.figure(figsize=(8, 6))
    pr_figure = plt.figure(figsize=(8, 6))
    roc_axes = roc_figure.add_subplot(111)
    pr_axes = pr_figure.add_subplot(111)
    fold_fpr_tpr = []
    best_auc_list = []  # 保存每一折中最好的AUC值

    print('starting fivefold cross validation..................')
    for i in range(0, len(positive_index_list), positive_split):
        count = count + 1
        print("This is {} fold cross validation".format(count))
        positive_train_index_to_zero = positive_index_list[i: i + positive_split]
        new_circrna_disease_matrix = circrna_disease_matrix.copy()
        # 五分之一的正样本置为0
        for index in positive_train_index_to_zero:
            new_circrna_disease_matrix[index[0], index[1]] = 0

        # relmatrix_to_tensor
        new_circrna_disease_matrix_tensor = torch.from_numpy(new_circrna_disease_matrix).to(device)

        # 标记其余四个没置0的正样本集，“0”表示负样本，“1”表示测试的正样本，“2”表示训练的正样本
        roc_circrna_disease_matrix = new_circrna_disease_matrix + circrna_disease_matrix

        # 异构邻接矩阵
        g = build_heterograph(new_circrna_disease_matrix, circSimi, disSimi).to(device)

        circSimi_mat = circSimi_mat.to(device)
        disSimi_mat = disSimi_mat.to(device)

        model = GATCNNMF(625, 93, 128, 8, 0.1, 0.3, 2778, 1).to(device)
        # 声明参数优化器
        optimizer = torch.optim.Adam(model.parameters(), lr=args.lr, weight_decay=args.weight_decay)
        # steps = []
        # loss_value = []

        """
           ++++++++++++++++++++++++++++++++++#获取just模型的数据+++++++++++++++++++++++++++++++++++++++++++++++
           """
        # just_result = get_just_result()

        max_auc = 0

        model.train()
        for epoch in range(2):
            t = time.time()
            # train_predict_result, train_lable = model(g, circSimi_mat, disSimi_mat, new_circrna_disease_matrix_tensor,just_result)
            train_predict_result, train_lable = model(g, circSimi_mat, disSimi_mat, new_circrna_disease_matrix_tensor)
            loss = F.binary_cross_entropy(train_predict_result, train_lable)
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
            y_label = train_lable.detach().numpy()
            y_pred = train_predict_result.detach().numpy()
            auc = roc_auc_score(y_label,y_pred )
            aupr = average_precision_score(y_label, y_pred)
            outputs = np.asarray([1 if i else 0 for i in (np.asarray(y_pred) >= 0.5)])
            recall = recall_score(y_label,outputs, labels=None, pos_label=1, average='binary', sample_weight=None,
                         zero_division="warn")
            precision = precision_score(y_label, outputs, average='binary')
            acc=accuracy_score(y_label, outputs,  normalize=True, sample_weight=None)
            f1 = f1_score(y_label,outputs)

            if auc > max_auc:
                model_max = copy.deepcopy(model)
                max_auc = auc
            print('Epoch: {:04d}'.format(epoch + 1),
                  'Loss: {:.4f}'.format(loss.item()),
                  'Auc: {:.4f}'.format(auc),
                  'Aupr: {:.4f}'.format(aupr),
                  'F1: {:.4f}'.format(f1),
                  'Acc: {:.4f}'.format(acc),
                  'Recall: {:.4f}'.format(recall),
                  'Precision: {:.4f}'.format(precision),
                  'Time: {:.4f}s'.format(time.time() - t))
            if hasattr(torch.cuda, 'empty_cache'):
                torch.cuda.empty_cache()
            all_auc.append(auc)
            all_aupr.append(aupr)
            all_F1.append(f1)
            all_acc.append(acc)
            all_precision.append(precision)
            all_recall.append(recall)

        model_max.eval()
        with torch.no_grad():
            train_predict_result, train_lable = model_max(g, circSimi_mat, disSimi_mat,
                                                          new_circrna_disease_matrix_tensor, just_result)
            y_label = train_lable.detach().numpy()
            y_pred = train_predict_result.detach().numpy()
            auc = roc_auc_score(y_label, y_pred)
            aupr = average_precision_score(y_label, y_pred)
            outputs = np.asarray([1 if i else 0 for i in (np.asarray(y_pred) >= 0.5)])
            recall = recall_score(y_label, outputs, labels=None, pos_label=1, average='binary', sample_weight=None,
                                  zero_division="warn")
            precision = precision_score(y_label, outputs, average='binary')
            acc = accuracy_score(y_label, outputs, normalize=True, sample_weight=None)
            f1 = f1_score(y_label, outputs)

            print(
                'Auc: {:.4f}'.format(auc),
                'Aupr: {:.4f}'.format(aupr),
                'F1: {:.4f}'.format(f1),
                'Acc: {:.4f}'.format(acc),
                'Recall: {:.4f}'.format(recall),
                'Precision: {:.4f}'.format(precision),
                'Time: {:.4f}s'.format(time.time() - t))

            y_pred_ = y_pred
            y_label_ = y_label
            outputs_ = outputs

        # 绘制ROC曲线
        fpr, tpr, thresholds = roc_curve(y_label_, y_pred_)
        auc_fold = roc_auc_score(y_label_, y_pred_)
        roc_axes.plot(fpr, tpr, label='Fold {} (AUC = {:.4f})'.format(count, auc_fold))
        all_auc.append(auc_fold)
        best_auc_list.append(np.max(auc_fold))  # 保存每一折中最好的AUC值

        # 绘制PR曲线
        precision, recall, _ = precision_recall_curve(y_label_, y_pred_)
        precision = precision[:-10]
        recall = recall[:-10]
        pr_axes.plot(recall, precision, lw=1, label='Fold {} (AUPR = {:.4f})'.format(count, aupr), alpha=0.5)
        all_aupr.append(aupr)
        fold_fpr_tpr.append((fpr, tpr))

    print("This is all folds cross validation over!".format(count))
    plt.close(roc_figure)  # 关闭ROC图形
    mean_fpr = np.linspace(0, 1, 100)
    mean_tpr = np.mean([np.interp(mean_fpr, fpr, tpr) for fpr, tpr in fold_fpr_tpr], axis=0)
    mean_auc = np.mean(all_auc)
    roc_axes.plot(mean_fpr, mean_tpr, label='Mean (AUC = {:.4f})'.format(mean_auc), color='k', linestyle='--')

    # 保存ROC图片
    roc_axes.set_xlim([-0.05, 1.05])
    roc_axes.set_ylim([-0.05, 1.05])
    roc_axes.plot([0, 1], [0, 1], 'k--')

    roc_axes.set_xlabel('False Positive Rate')
    roc_axes.set_ylabel('True Positive Rate')
    roc_axes.set_title('ROC Curve')
    roc_axes.legend(loc="lower right")
    roc_figure.savefig('ROC1.png')
    plt.close(roc_figure)  # 关闭ROC图形

    # 计算五折平均PR曲线
    mean_precision, mean_recall, _ = precision_recall_curve(y_label_, y_pred_)
    mean_precision = mean_precision[:-10]
    mean_recall = mean_recall[:-10]
    pr_axes.plot(mean_recall, mean_precision, lw=2, label='Mean (AUPR = {:.4f})'.format(np.mean(all_aupr)), color='k',
                 linestyle='--')

    # 保存PR图片
    pr_axes.set_xlim([-0.05, 1.05])
    pr_axes.set_ylim([-0.05, 1.05])
    pr_axes.plot([0, 1], [1, 0], 'k--')
    pr_axes.set_xlabel('Recall')
    pr_axes.set_ylabel('Precision')
    pr_axes.set_title('PR Curve')
    pr_axes.legend(loc="lower right")
    pr_figure.savefig('PR1.png')
    plt.close(pr_figure)  # 关闭PR图形

    # # 计算五折平均指标
    # mean_auc = np.mean(all_auc)
    # mean_aupr = np.mean(all_aupr)
    # mean_f1 = np.mean(all_F1)
    # mean_acc = np.mean(all_acc)
    # mean_precision = np.mean(all_precision)
    # mean_recall = np.mean(all_recall)

    # 打印每一折中最好的AUC值
    print("Best AUC values for each fold:", best_auc_list)

    # 计算和打印五折平均的性能指标
    print("Calculating and printing five-fold average metrics...")

    mean_auc = np.mean(all_auc)
    mean_aupr = np.mean(all_aupr)
    mean_f1 = np.mean(all_F1)
    mean_acc = np.mean(all_acc)
    mean_precision = np.mean(all_precision)
    mean_recall = np.mean(all_recall)

    print(
        'Mean Auc: {:.4f}'.format(mean_auc),
        'Mean Aupr: {:.4f}'.format(mean_aupr),
        'Mean F1: {:.4f}'.format(mean_f1),
        'Mean Acc: {:.4f}'.format(mean_acc),
        'Mean Recall: {:.4f}'.format(mean_recall),
        'Mean Precision: {:.4f}'.format(mean_precision)
    )