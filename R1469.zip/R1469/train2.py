import argparse
import copy
import math
import random
import time
from mpl_toolkits.axes_grid1.inset_locator import mark_inset
import numpy as np
import pandas as pd
import torch
import torch.nn.functional as F
from sklearn.metrics import roc_auc_score, average_precision_score, f1_score, accuracy_score, recall_score, \
    precision_score, roc_curve, precision_recall_curve
import dgl
from GATCL import GATCNNMF
from just import get_just_result
from utils import build_heterograph, sort_matrix, GKL
from scipy.interpolate import interp1d
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

# 参数设置
parser = argparse.ArgumentParser()
parser.add_argument('--no-cuda', action='store_true', default=True,
                    help='Disables CUDA training.')
parser.add_argument('--seed', type=int, default=2022, help='Random seed.')
parser.add_argument('--epochs', type=int, default=1,  # 基本上100就已经达到效果了
                    help='Number of epochs to train.')
parser.add_argument('--lr', type=float, default=0.0001,
                    help='Learning rate.')
parser.add_argument('--weight_decay', type=float, default=1e-7,
                    help='Weight decay (L2 loss on parameters).')
parser.add_argument('--hidden', type=int, default=64,
                    help='Dimension of representations')




if __name__ == '__main__':
    device = torch.device("cpu")
    args = parser.parse_args()
    # np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    # 读取邻接矩阵,625*93,associations:674
    A = np.loadtxt('./data599/associationMatrix_599_88.csv', delimiter=',')
    circSimi = np.loadtxt('./data599/Integrated_sqe_fun_circRNA_similarity_599.csv', delimiter=',')
    disSimi = np.loadtxt('./data599/Integrated_gip_DO_disease_similarity_88.csv', delimiter=',')

    circSimi_mat = torch.from_numpy(circSimi).to(torch.float32)
    disSimi_mat = torch.from_numpy(disSimi).to(torch.float32)

    circrna_disease_matrix = np.copy(A)
    rna_numbers = circrna_disease_matrix.shape[0]
    dis_number = circrna_disease_matrix.shape[1]

    # 寻找正样本的索引
    positive_index_tuple = np.where(circrna_disease_matrix == 1)
    positive_index_list = list(zip(positive_index_tuple[0], positive_index_tuple[1]))
    # 随机打乱
    random.shuffle(positive_index_list)
    # 将正样本分为5个数量相等的部分
    positive_split = math.ceil(len(positive_index_list) / 5)

    all_aupr = []
    all_auc = []
    all_F1 = []
    all_acc = []
    all_recall = []
    all_precision = []
    y_label_ =[]
    y_pred_ =[]
    outputs_ = []
    all_aupr_values = []
    count = 0
    mean_fpr = np.linspace(0, 1, 100)
    all_tpr = []
    # 5-fold
    t1 = time.time()
    plt.figure()
    # 创建ROC和PR图形
    best_auc_per_fold = []
    best_aupr_per_fold = []
    print('..................starting fivefold cross validation..................')
    # 创建一张图
    plt.figure()

    all_pr_curves = []  # 存储所有PR曲线的列表
    all_roc_curves = []
    mean_recall = np.linspace(0, 1, 100)  # 添加这一行
    for i in range(0, len(positive_index_list), positive_split):
        count = count + 1
        print("This is {} fold cross validation".format(count))
        positive_train_index_to_zero = positive_index_list[i: i + positive_split]
        new_circrna_disease_matrix = circrna_disease_matrix.copy()
        # 五分之一的正样本置为0
        for index in positive_train_index_to_zero:
            new_circrna_disease_matrix[index[0], index[1]] = 0

        # relmatrix_to_tensor
        new_circrna_disease_matrix_tensor = torch.from_numpy(new_circrna_disease_matrix).to(device)

        # 标记其余四个没置0的正样本集，“0”表示负样本，“1”表示测试的正样本，“2”表示训练的正样本
        roc_circrna_disease_matrix = new_circrna_disease_matrix + circrna_disease_matrix

        # 异构邻接矩阵
        g = build_heterograph(new_circrna_disease_matrix, circSimi, disSimi).to(device)
        g = dgl.add_self_loop(g)

        circSimi_mat = circSimi_mat.to(device)
        disSimi_mat = disSimi_mat.to(device)

        # model = GATCNNMF(625, 93, 128, 8, 0.1, 0.3, 2778, 1).to(device)
        model = GATCNNMF(599, 88, 128, 8, 0.1, 0.3, 2778, 1).to(device)
        # 声明参数优化器
        optimizer = torch.optim.Adam(model.parameters(), lr=args.lr, weight_decay=args.weight_decay)
        # steps = []
        # loss_value = []

        """
           ++++++++++++++++++++++++++++++++++#获取just模型的数据+++++++++++++++++++++++++++++++++++++++++++++++
           """
        just_result = get_just_result()

        max_auc = 0
        model_max = None
        best_epoch_auc = 0

        model.train()
        for epoch in range(1):
            t = time.time()
            train_predict_result, train_lable = model(g, circSimi_mat, disSimi_mat, new_circrna_disease_matrix_tensor,just_result)
            # train_predict_result, train_lable = model(g, circSimi_mat, disSimi_mat, new_circrna_disease_matrix_tensor)
            loss = F.binary_cross_entropy(train_predict_result, train_lable)
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
            y_label = train_lable.detach().numpy()
            y_pred = train_predict_result.detach().numpy()
            auc = roc_auc_score(y_label,y_pred )
            aupr = average_precision_score(y_label, y_pred)
            outputs = np.asarray([1 if i else 0 for i in (np.asarray(y_pred) >= 0.5)])
            recall = recall_score(y_label,outputs, labels=None, pos_label=1, average='binary', sample_weight=None,
                         zero_division="warn")
            precision = precision_score(y_label, outputs, average='binary')
            acc=accuracy_score(y_label, outputs,  normalize=True, sample_weight=None)
            f1 = f1_score(y_label,outputs)

            if auc > max_auc:
                model_max = copy.deepcopy(model)
                max_auc = auc

            print('Epoch: {:04d}'.format(epoch + 1),
                  'Loss: {:.4f}'.format(loss.item()),
                  'Auc: {:.4f}'.format(auc),
                  'Aupr: {:.4f}'.format(aupr),
                  'F1: {:.4f}'.format(f1),
                  'Acc: {:.4f}'.format(acc),
                  'Recall: {:.4f}'.format(recall),
                  'Precision: {:.4f}'.format(precision),
                  'Time: {:.4f}s'.format(time.time() - t))
            if hasattr(torch.cuda, 'empty_cache'):
                torch.cuda.empty_cache()
            all_auc.append(auc)
            all_aupr.append(aupr)
            all_F1.append(f1)
            all_acc.append(acc)
            all_precision.append(precision)
            all_recall.append(recall)

            best_auc_per_fold.append(max_auc)

            model_max.eval()
            with torch.no_grad():
                train_predict_result, train_lable = model_max(g, circSimi_mat, disSimi_mat,new_circrna_disease_matrix_tensor, just_result)
                # train_predict_result, train_lable = model_max(g, circSimi_mat, disSimi_mat,
                #                                               new_circrna_disease_matrix_tensor)
                y_label = train_lable.detach().numpy()
                y_pred = train_predict_result.detach().numpy()
                auc = roc_auc_score(y_label, y_pred)
                aupr = average_precision_score(y_label, y_pred)
                outputs = np.asarray([1 if i else 0 for i in (np.asarray(y_pred) >= 0.5)])
                recall = recall_score(y_label, outputs, labels=None, pos_label=1, average='binary', sample_weight=None,
                                      zero_division="warn")
                precision = precision_score(y_label, outputs, average='binary')
                acc = accuracy_score(y_label, outputs, normalize=True, sample_weight=None)
                f1 = f1_score(y_label, outputs)

                if auc > max_auc:
                    model_max = copy.deepcopy(model)
                    max_auc = auc
                    best_epoch_auc = epoch
                print(
                    'Auc: {:.4f}'.format(auc),
                    'Aupr: {:.4f}'.format(aupr),
                    'F1: {:.4f}'.format(f1),
                    'Acc: {:.4f}'.format(acc),
                    'Recall: {:.4f}'.format(recall),
                    'Precision: {:.4f}'.format(precision),
                    'Time: {:.4f}s'.format(time.time() - t))
        # 创建ROC曲线
        fpr, tpr, thresholds = roc_curve(y_label, y_pred)
        roc_auc = roc_auc_score(y_label, y_pred)
        all_roc_curves.append((fpr, tpr, roc_auc))

        # 创建AUPR曲线
        precision_fold, recall_fold, thresholds_fold = precision_recall_curve(y_label, y_pred)
        aupr_value = average_precision_score(y_label, y_pred)
        all_pr_curves.append((recall_fold, precision_fold, aupr_value))  # 存储AUPR曲线和对应的AUPR值

    # 创建平均AUPR曲线
    all_aupr_values = []
    all_precision_values = []

    # 初始化一个矩阵用于存储每个fold的插值结果
    interp_precision_matrix = np.zeros((len(all_pr_curves), len(mean_recall)))

    # 为所有折叠计算插值
    for i, (recall_fold, precision_fold, aupr_value) in enumerate(all_pr_curves, start=1):
        if len(recall_fold) > 0 and len(precision_fold) > 0:
            plt.plot(recall_fold, precision_fold, label='Fold {} (AUPR = {:.4f})'.format(i, aupr_value))
            all_aupr_values.append(aupr_value)

            # 使用interp1d进行插值
            interp_func = interp1d(recall_fold, precision_fold, kind='linear', fill_value='extrapolate')
            interp_precision_fold = interp_func(mean_recall)

            # 将插值结果存储在矩阵中
            interp_precision_matrix[i - 1, :] = interp_precision_fold

    # 创建平均AUPR曲线
    all_precision_values = interp_precision_matrix.tolist()
    mean_precision_values = np.mean(all_precision_values, axis=0)
    average_aupr = np.mean(all_aupr_values)

    # 确保 mean_recall 与 mean_precision_values 的长度相同
    mean_recall = np.linspace(0, 1, len(mean_precision_values))

    plt.plot(mean_recall, mean_precision_values, color='teal', label='Average (AUPR = {:.4f})'.format(average_aupr),
             linestyle='--')
    # 添加局部放大的代码
    ax = plt.gca()
    axins = ax.inset_axes([0.1, 0.5, 0.35, 0.35])  # 定义局部放大的区域 [left, bottom, width, height]

    # 在局部放大区域绘制每个fold的AUPR曲线
    for i, (recall_fold, precision_fold, aupr_value) in enumerate(all_pr_curves, start=1):
        if len(recall_fold) > 0 and len(precision_fold) > 0:
            interp_func = interp1d(recall_fold, precision_fold, kind='linear', fill_value='extrapolate')
            interp_precision_fold = interp_func(mean_recall)
            axins.plot(mean_recall, interp_precision_fold, label='Fold {} (AUPR = {:.4f})'.format(i, aupr_value))

    # 在局部放大区域绘制平均AUPR曲线
    axins.plot(mean_recall, mean_precision_values, color='teal', label='Average (AUPR = {:.4f})'.format(average_aupr),
               linestyle='--')

    # 设置局部放大区域的x轴和y轴范围
    axins.set_xlim(0.9, 1.0)  # 设置x轴范围
    axins.set_ylim(0.9, 1.0)  # 设置y轴范围

    # 将局部放大区域添加到主图中
    # ax.indicate_inset_zoom(axins)

    mark_inset(ax, axins, loc1=2, loc2=4, fc="none", ec="0.5", linestyle='--', label=None)

    plt.plot([0, 1], [1, 0], color='black', lw=2, linestyle='--')
    plt.xlabel('Recall')
    plt.ylabel('Precision')
    plt.title('AUPR Curve - All Folds')
    plt.legend(loc="lower left")
    plt.savefig('Combined_AUPR_All_Folds4.png')
    # 创建平均AUPR曲线
    # 创建平均AUPR曲线
    # all_aupr_values = []
    # all_precision_values = []
    #
    # # 初始化一个矩阵用于存储每个fold的插值结果
    # interp_precision_matrix = np.zeros((len(all_pr_curves), len(mean_recall)))
    #
    # # 为所有折叠计算插值
    # for i, (recall_fold, precision_fold, aupr_value) in enumerate(all_pr_curves, start=1):
    #     if len(recall_fold) > 0 and len(precision_fold) > 0:
    #         plt.plot(recall_fold, precision_fold, label='Fold {} (AUPR = {:.4f})'.format(i, aupr_value))
    #         all_aupr_values.append(aupr_value)
    #
    #         # 修复：使用interp1d进行插值
    #         interp_func = interp1d(recall_fold, precision_fold, kind='linear', fill_value='extrapolate')
    #         interp_precision_fold = interp_func(mean_recall)
    #
    #         # 将插值结果存储在矩阵中
    #         interp_precision_matrix[i - 1, :] = interp_precision_fold
    #
    # # 创建平均AUPR曲线
    # mean_precision_values = np.mean(interp_precision_matrix, axis=0)
    # average_aupr = np.mean(all_aupr_values)
    #
    # # 绘制平均AUPR曲线
    # if mean_precision_values.shape[0] > 0:
    #     plt.plot(mean_recall, mean_precision_values, color='teal', label='Average (AUPR = {:.4f})'.format(average_aupr),
    #              linestyle='--')
    # else:
    #     print("Warning: mean_precision_values is empty. Unable to plot.")
    #
    # plt.plot([0, 1], [1, 0], color='black', lw=2, linestyle='--')
    # plt.xlabel('Recall')
    # plt.ylabel('Precision')
    # plt.title('AUPR Curve - All Folds')
    # plt.legend(loc="lower left")
    # plt.savefig('Combined_AUPR_All_Folds.png')

    plt.figure()
    mean_fpr = np.linspace(0, 1, 100)
    avg_roc_curve = np.mean([np.interp(mean_fpr, fpr, tpr) for fpr, tpr, _ in all_roc_curves], axis=0)
    avg_roc_auc = np.mean([roc_auc for _, _, roc_auc in all_roc_curves])
    for i, (fpr, tpr, roc_auc) in enumerate(all_roc_curves, start=1):
        plt.plot(fpr, tpr, label='Fold {} (AUC = {:.4f})'.format(i, roc_auc))
    # for i, (_, _, roc_auc) in enumerate(all_roc_curves, start=1):
    #     print('折叠 {}: AUC = {:.4f}'.format(i, roc_auc))
    plt.plot(mean_fpr, avg_roc_curve, color='teal', label='Average (AUC = {:.4f})'.format(avg_roc_auc), linestyle='--')
    # 将所有ROC曲线绘制在同一张图上
    # 添加局部放大的代码
    ax = plt.gca()
    axins = ax.inset_axes([0.5, 0.5, 0.35, 0.35])  # 定义局部放大的区域 [left, bottom, width, height]

    # 在局部放大区域绘制ROC曲线
    for i, (fpr, tpr, roc_auc) in enumerate(all_roc_curves, start=1):
        axins.plot(fpr, tpr, label='Fold {} (AUC = {:.4f})'.format(i, roc_auc))
    axins.plot(mean_fpr, avg_roc_curve, color='teal', label='Average (AUC = {:.4f})'.format(avg_roc_auc), linestyle='--')
    axins.plot([0, 1], [0, 1], 'k--')  # 绘制参考线
    axins.set_xlim(0.00, 0.10)  # 设置局部放大区域的x轴范围
    axins.set_ylim(0.9, 1.0)  # 设置局部放大区域的y轴范围
    axins.legend()

    # 禁用局部放大图的图注
    axins.legend_.set_visible(False)
    # 将局部放大区域添加到主图中
    # ax.indicate_inset_zoom(axins)
    mark_inset(ax, axins, loc1=2, loc2=4, fc="none", ec="0.5", linestyle='--', label=None)
    plt.plot([0, 1], [0, 1], color='black', lw=2, linestyle='--')
    plt.xlabel('False Positive Rate')
    plt.ylabel('True Positive Rate')
    plt.title('Receiver Operating Characteristic (ROC) Curve - All Folds')
    plt.legend(loc="lower right")
    plt.savefig('Combined_ROC_All_Folds4.png')

    # 保存平均 AUC 的 FPR 和 TPR 到文件
    mean_roc_data = np.column_stack((mean_fpr, avg_roc_curve))
    np.save('mean_auc_fpr_tpr4.npy', mean_roc_data)

    # F1、Acc、Recall和Precision的平均值
    avg_f1 = np.mean(all_F1)
    avg_acc = np.mean(all_acc)
    avg_recall = np.mean(all_recall)
    avg_precision = np.mean(all_precision)

    # 打印平均值
    print('Average AUC: {:.4f}'.format(avg_roc_auc))
    print('Average AUPR: {:.4f}'.format(average_aupr))
    print('Average F1: {:.4f}'.format(avg_f1))
    print('Average Acc: {:.4f}'.format(avg_acc))
    print('Average Recall: {:.4f}'.format(avg_recall))
    print('Average Precision: {:.4f}'.format(avg_precision))