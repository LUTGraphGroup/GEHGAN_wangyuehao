# import numpy as np
# import openpyxl
# import pandas as pd
#
# # 使用高斯核计算相似性
# def gaussian_similarity(x, y, sigma=1.0):
#     return np.exp(-np.linalg.norm(x - y) ** 2 / (2 * sigma ** 2))
#
#
# def complete_similarity_matrix(similarity_matrix):
#     num_diseases = similarity_matrix.shape[0]
#     completed_matrix = np.zeros((num_diseases, num_diseases))
#
#     # 使用高斯核相似性来补全相似性矩阵
#     for i in range(num_diseases):
#         for j in range(num_diseases):
#             if i == j:
#                 completed_matrix[i, j] = 1.0  # 对角线上的相似性为1
#             else:
#                 completed_matrix[i, j] = gaussian_similarity(similarity_matrix[i], similarity_matrix[j])
#
#     return completed_matrix
#
# # def fill_matrix(mat1,mat2):
# #     rows = mat1.shape[0]
# #     cols = mat1.shape[1]
# #     #复制一份防止修改原文件
# #     mat1_copy = mat1.copy()
# #     for i in range(rows):
# #         for j in range(cols):
# #             if mat1[i][j] == 0.0:
# #                 #mat1_copy[i][j] = mat2[i][j]a'na
# #                 mat1_copy.loc[i, j] = mat2[i][j]
# #     return mat1_copy
# def fill_matrix(mat1, mat2):
#     mat1_copy = mat1.copy()
#     for i in range(mat1.shape[0]):
#         for j in range(mat1.shape[1]):
#             mat1_copy.at[i, j] = mat2[i][j]
#     return mat1_copy
#
# # 主程序
# if __name__ == "__main__":
#     # 从本地文件读取疾病语义相似性数据
#     similarity_matrix = pd.read_csv(r'F:\daixie\New folder\data\dis_met_mat.csv',header=None)
#     DMS = np.load(r'F:\daixie\New folder\DMS.npy')
#     print(similarity_matrix.shape)
#     # 补全相似性矩阵
#     completed_matrix = complete_similarity_matrix(similarity_matrix)
#
#     # 保存补全后的相似性矩阵到 Excel 文件
#     excel_file_path = r'F:\daixie\New folder\GS_DMS.xlsx'
#     workbook = openpyxl.Workbook()
#     sheet = workbook.active
#
#     for row in completed_matrix:
#         sheet.append(row.tolist())
#
#     workbook.save(excel_file_path)
#
#     print("Completed Similarity Matrix saved to Excel file:", excel_file_path)
#
#     dms_completed = fill_matrix(DMS, similarity_matrix)
#     excel_file_path = r'F:\daixie\New folder\GS_DMS1.xlsx'
# import numpy as np
# import openpyxl
# import pandas as pd
#
#
# # 使用高斯核计算相似性
# def gaussian_similarity(x, y, sigma=1.0):
#     return np.exp(-np.linalg.norm(x - y) ** 2 / (2 * sigma ** 2))
#
#
# def complete_similarity_matrix(similarity_matrix):
#     num_diseases = similarity_matrix.shape[0]
#     completed_matrix = np.zeros((num_diseases, num_diseases))
#
#     # 使用高斯核相似性来补全相似性矩阵
#     for i in range(num_diseases):
#         for j in range(num_diseases):
#             if i == j:
#                 completed_matrix[i, j] = 1.0  # 对角线上的相似性为1
#             else:
#                 completed_matrix[i, j] = gaussian_similarity(similarity_matrix[i], similarity_matrix[j])
#
#     return completed_matrix
#
#
# def fill_matrix(mat1, mat2):
#     mat1_copy = mat1.copy()
#     for i in range(mat1.shape[0]):
#         for j in range(mat1.shape[1]):
#             if mat1[i, j] == 0.0:
#                 mat1_copy[i, j] = mat2[i, j]
#     return mat1_copy
#
#
# # 主程序
# if __name__ == "__main__":
#     # 从本地文件读取疾病语义相似性数据
#     similarity_matrix = np.loadtxt(r'F:\daixie\New folder\data\dis_met_mat.csv', delimiter=',')
#     DMS = np.load(r'F:\daixie\New folder\DMS.npy')
#     print(similarity_matrix.shape)
#
#     # 补全相似性矩阵
#     completed_matrix = complete_similarity_matrix(similarity_matrix)
#
#     # 保存补全后的相似性矩阵到 Excel 文件
#     excel_file_path = r'F:\daixie\New folder\GS_DMS.xlsx'
#     workbook = openpyxl.Workbook()
#     sheet = workbook.active
#
#     for row in completed_matrix:
#         sheet.append(row.tolist())
#
#     workbook.save(excel_file_path)
#
#     print("Completed Similarity Matrix saved to Excel file:", excel_file_path)
#
#     dms_completed = fill_matrix(DMS, completed_matrix)
#     excel_file_path1 = r'F:\daixie\New folder\GS_DMS1.xlsx'
#     np.save(excel_file_path, dms_completed)

import numpy as np
import openpyxl
import pandas as pd


# 使用高斯核计算相似性
def gaussian_similarity(x, y, sigma=0.8):
    return np.exp(-np.linalg.norm(x - y) ** 2 / (2 * sigma ** 2))


def complete_similarity_matrix(similarity_matrix):
    num_diseases = similarity_matrix.shape[0]
    completed_matrix = np.zeros((num_diseases, num_diseases))

    # 使用高斯核相似性来补全相似性矩阵
    for i in range(num_diseases):
        for j in range(num_diseases):
            if i == j:
                completed_matrix[i, j] = 1.0  # 对角线上的相似性为1
            else:
                completed_matrix[i, j] = gaussian_similarity(similarity_matrix[i], similarity_matrix[j])

    return completed_matrix


def fill_matrix(mat1, mat2):
    mat1_copy = mat1.copy()
    for i in range(mat1.shape[1]):
        for j in range(mat1.shape[0]):
            if mat1[i, j] == 0.0:
                mat1_copy[i, j] = mat2[i, j]
    return mat1_copy


# 主程序
if __name__ == "__main__":
    # 从本地文件读取疾病语义相似性数据
    # similarity_matrix = np.loadtxt(r'F:\RNA疾病预测\R1469_Code\R1469\GS\associationMatrix.xlsx', delimiter=',')
    # DMS = np.load(r'F:\RNA疾病预测\R1469_Code\R1469\GS\DMS.npy')
    # print(similarity_matrix.shape)
    excel_file_path = r'F:\疾病预测\RNA基础\599\associationMatrix.xlsx'
    workbook = openpyxl.load_workbook(excel_file_path)
    sheet = workbook.active
    # 初始化一个空的列表来存储数据
    data = []

    for row in sheet.iter_rows(values_only=True):
        ## 检查单元格是否为整数，如果是整数则设置为0，否则获取其值
        row_data = [cell if cell is not None else 0 for cell in row]
        data.append(row_data)

    # 将数据列表转换为 NumPy 数组
    similarity_matrix = np.array(data)
    # DMS = np.load(r'F:\RNA疾病预测\R1469_Code\R1469\GS\RNA Sequence similarity.npy')
    excel_file_path = r'F:\疾病预测\R1469_Code\R1469\data599\DMS.xlsx'
    df = pd.read_excel(excel_file_path, header=None)  # 如果文件中没有列名，请设置header=None

    # 将DataFrame转换为Numpy数组（如果需要）
    DMS = df.to_numpy()
    print(similarity_matrix.shape)
    # 补全相似性矩阵
    completed_matrix = complete_similarity_matrix(similarity_matrix)

    # 保存补全后的相似性矩阵到 Excel 文件
    excel_file_path = r'F:\疾病预测\R1469_Code\R1469\data599\GS_dis similarity.xlsx'
    workbook = openpyxl.Workbook()
    sheet = workbook.active

    for row in completed_matrix:
        sheet.append(row.tolist())

    workbook.save(excel_file_path)

    print("Completed Similarity Matrix saved to Excel file:", excel_file_path)

    dms_completed = fill_matrix(DMS, completed_matrix)
    dms_excel_file_path = r'F:\疾病预测\R1469_Code\R1469\data599\GS_dis similarity1.xlsx'

    # 将NumPy数组保存为Excel文件
    df = pd.DataFrame(dms_completed)
    df.to_excel(dms_excel_file_path, index=False, header=False)

    print("Completed DMS saved to Excel file:", dms_excel_file_path)

# import pandas as pd
# import numpy as np
#
# # 读取语义相似性矩阵
# semantic_similarity_matrix = pd.read_excel("F:/RNA疾病预测/R1469_Code/R1469/GS/DMS.xlsx", index_col=0)
#
# # 读取关联关系矩阵
# association_matrix = pd.read_excel("F:/RNA疾病预测/R1469_Code/R1469/GS/associationMatrix.xlsx", index_col=0)
#
# # 计算高斯核相似性的带宽参数
# sigma = 1.0  # 你可以根据需要调整这个值
#
# # 初始化高斯核相似性矩阵
# gaussian_similarity_matrix = np.zeros(semantic_similarity_matrix.shape)
#
# # 遍历疾病对，计算高斯核相似性
# for i in range(semantic_similarity_matrix.shape[0]):
#     for j in range(semantic_similarity_matrix.shape[1]):
#         semantic_similarity = semantic_similarity_matrix.iloc[i, j]
#         association_score = association_matrix.iloc[:, i].dot(association_matrix.iloc[:, j])
#         gaussian_similarity = np.exp(-((semantic_similarity ** 2) / (2 * sigma ** 2))) * association_score
#         gaussian_similarity_matrix[i, j] = gaussian_similarity
#
# # 补全语义相似性矩阵中为0的元素
# for i in range(semantic_similarity_matrix.shape[0]):
#     for j in range(semantic_similarity_matrix.shape[1]):
#         if semantic_similarity_matrix.iloc[i, j] == 0:
#             semantic_similarity_matrix.iloc[i, j] = gaussian_similarity_matrix[i, j]
#
# # 将高斯核相似性矩阵保存到文件
# gaussian_similarity_df = pd.DataFrame(gaussian_similarity_matrix, index=semantic_similarity_matrix.index, columns=semantic_similarity_matrix.columns)
# gaussian_similarity_df.to_excel("F:/RNA疾病预测/R1469_Code/R1469/GS/GaussianSimilarity.xlsx")