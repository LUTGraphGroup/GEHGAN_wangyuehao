# import requests
# import numpy as np
# response = requests.get(url='http://bioinformatics.csu.edu.cn/limin/index.html')
#
# print(response.text)
import requests

# Send a GET request
response = requests.get(url='http://bioinformatics.csu.edu.cn/limin/index.html')

# Check if the request was successful (status code 200)
if response.status_code == 200:
    # Save the response text to a text file
    file_path = 'response_text.txt'
    with open(file_path, 'w', encoding='utf-8') as file:
        file.write(response.text)
        print(f'Text saved to {file_path}')
else:
    print('Error:', response.status_code)
